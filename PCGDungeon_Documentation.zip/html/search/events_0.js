var searchData=
[
  ['_5fdevlayout_1054',['_devLayout',['../class_u_i_manager.html#a780c75351f00c8adfa82b42f3252cef3',1,'UIManager']]],
  ['_5fuserlayout_1055',['_userLayout',['../class_u_i_manager.html#a9130af45ec019009c0a6e381e75a6ff0',1,'UIManager']]]
];
