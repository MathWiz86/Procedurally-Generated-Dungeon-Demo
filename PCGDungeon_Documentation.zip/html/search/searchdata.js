var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvwz",
  1: "cdeghimortuv",
  2: "dp",
  3: "cdeghimortuv",
  4: "abcdefghilmnoprstuvwz",
  5: "_abcdefghilmnoprstvwz",
  6: "cdhtw",
  7: "bcdeghimnoprsw",
  8: "abcdefimprstuv",
  9: "_"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events"
};

