var searchData=
[
  ['triangle_549',['Triangle',['../class_delaunay_1_1_triangle.html',1,'Delaunay']]]
];
