var searchData=
[
  ['delaunay_555',['Delaunay',['../namespace_delaunay.html',1,'']]]
];
