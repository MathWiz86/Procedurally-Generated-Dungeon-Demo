var dir_7150b6701f2f0126be68a056f4f55cfc =
[
    [ "DebugInfo.cs", "_debug_info_8cs.html", [
      [ "DebugInfo", "class_debug_info.html", "class_debug_info" ]
    ] ],
    [ "DisplayTexture.cs", "_display_texture_8cs.html", [
      [ "DisplayTexture", "class_display_texture.html", "class_display_texture" ]
    ] ],
    [ "GUIExample.cs", "_g_u_i_example_8cs.html", [
      [ "GUIExample", "class_g_u_i_example.html", "class_g_u_i_example" ]
    ] ],
    [ "ImGuiDemo.cs", "_im_gui_demo_8cs.html", [
      [ "ImGuiDemo", "class_im_gui_demo.html", "class_im_gui_demo" ]
    ] ],
    [ "UIManager.cs", "_u_i_manager_8cs.html", [
      [ "UIManager", "class_u_i_manager.html", "class_u_i_manager" ]
    ] ]
];