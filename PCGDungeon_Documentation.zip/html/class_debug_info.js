var class_debug_info =
[
    [ "OnDevLayout", "class_debug_info.html#ac9527e028aa201234f9691dda8fcb851", null ],
    [ "OnEnable", "class_debug_info.html#a38fc8b61314e78775637a22841e0d510", null ],
    [ "Start", "class_debug_info.html#a18d45bf325c80e1c4fcaf6df9fc6e8c0", null ],
    [ "average", "class_debug_info.html#a4cf995fb69b99616c3929d7c0ea4ae7f", null ],
    [ "currentIndex", "class_debug_info.html#af9ab2aba7ac249369ea70b5ef62cc1bf", null ],
    [ "fps", "class_debug_info.html#a6b354fda7d330554e300c5b02b1b1125", null ],
    [ "savedValues", "class_debug_info.html#a9f26cc3c0927d5d5694f7b3c3d95d596", null ]
];