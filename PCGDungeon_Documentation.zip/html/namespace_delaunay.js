var namespace_delaunay =
[
    [ "Delaunay", "class_delaunay_1_1_delaunay.html", "class_delaunay_1_1_delaunay" ],
    [ "Edge", "class_delaunay_1_1_edge.html", "class_delaunay_1_1_edge" ],
    [ "Triangle", "class_delaunay_1_1_triangle.html", "class_delaunay_1_1_triangle" ],
    [ "Vertex", "class_delaunay_1_1_vertex.html", null ]
];